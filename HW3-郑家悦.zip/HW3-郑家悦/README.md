放置路径：直接在 HW3-郑家悦/ 根目录下新建 README.md，粘贴以下内容保存。   Markdown# Target 3: 比较并改进 Ray Serve 路由策略实验

## 1. 实验硬件环境与软件版本
- **GPU**: 4 × NVIDIA RTX 4090 (24GB VRAM)
- **CPU**: 16 vCPU Intel(R) Xeon(R) Platinum
- **操作系统**: Ubuntu 22.04 LTS
- **Python**: 3.11 (Conda 环境: `ray_env`)
- **核心依赖**:
  - `ray`: 2.40.0+ (支持 Ray Serve 与 `ray.cluster_utils.Cluster`)
  - `sglang`: 0.4.0+
  - `torch`: 2.4.0+cu121
  - `httpx`: 0.27.0+
  - `starlette`: 0.38.0+

## 2. 依赖安装方法
```bash
pip install -r src/requirements.txt
3. 服务启动与回放命令(1) 启动底层 SGLang 后端 (4 实例)分别在 4 个独立终端窗口中，在对应的 GPU 上启动独立的 SGLang 服务：Bash# Backend 0 (端口 30000)
CUDA_VISIBLE_DEVICES=0 python -m sglang.launch_server --model-path /root/qwen-0.5b --port 30000 --host 127.0.0.1

# Backend 1 (端口 30001)
CUDA_VISIBLE_DEVICES=1 python -m sglang.launch_server --model-path /root/qwen-0.5b --port 30001 --host 127.0.0.1

# Backend 2 (端口 30002)
CUDA_VISIBLE_DEVICES=2 python -m sglang.launch_server --model-path /root/qwen-0.5b --port 30002 --host 127.0.0.1

# Backend 3 (端口 30003)
CUDA_VISIBLE_DEVICES=3 python -m sglang.launch_server --model-path /root/qwen-0.5b --port 30003 --host 127.0.0.1
(2) 启动 Ray Serve 网关在独立的网关窗口运行集群拓扑与自定义路由代理：Bashpython src/start_cluster_serve.py
(3) 流量回放与压测命令 (以 D 组为例)Bashpython src/run_workload.py \
  --policy serve \
  --run-name D_improved \
  --router-name hybrid_prefix_aware \
  --max-ongoing-requests 32 \
  --base-url [http://127.0.0.1:8000](http://127.0.0.1:8000) \
  --model /root/qwen-0.5b \
  --workload mooncake_prefix_workload_v2_seed2026.jsonl \
  --max-in-flight 2048 \
  --overwrite \
  --output-dir results/target3/D_improved
4. 脚本用途说明src/start_cluster_serve.py: 建立 1 Head + 4 Worker 逻辑集群拓扑，部署 Ray Serve 网关，内置 Group D 改进的 HybridPrefixAwareRouter 实现与响应头注入逻辑。src/run_workload.py: 固定测试负载回放驱动，按 trace 规定的到达时间发起预热与测量请求并统计端到端指标。
compare_runs.py: 官方基准横向比对工具，比对并生成 comparison.json。
5. 结果目录与报告表格对应关系results/target3/A_default/summary.json: 对应报告主表 Group A (默认 P2C, max_ongoing=5)。results/target3/B_candidates/candidate-1/summary.json: 对应报告主表 Group B1 (候选参数 16)。results/target3/B_candidates/candidate-2/summary.json: 对应报告主表 Group B2 (候选参数 32，最终选定)。results/target3/C_affinity/summary.json: 对应报告主表 Group C (纯一致性哈希前缀亲和)。results/target3/D_improved/summary.json: 对应报告主表 Group D (混合自适应改进策略)。results/target3/comparison.json: 官方对比脚本生成的最终比对汇总数据。