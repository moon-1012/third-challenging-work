import hashlib
import json
import time
import asyncio
import httpx
from starlette.requests import Request
from starlette.responses import StreamingResponse
from ray import serve
from ray.cluster_utils import Cluster

# 1. 逻辑集群拓扑 (1 head + 4 worker)
cluster = Cluster()
cluster.add_node(resources={"head": 1})
for i in range(4):
    cluster.add_node(resources={f"worker_{i}": 1})

import ray
ray.init(address=cluster.address)

# 2. 混合自适应路由器 (Group D: Robust HybridPrefixAwareRouter)
@serve.deployment(max_ongoing_requests=32)
class HybridPrefixAwareRouter:
    def __init__(self):
        self.ports = [30000, 30001, 30002, 30003]
        # 调大连接池上限与超时时间，防止高并发下 socket 耗尽
        limits = httpx.Limits(max_connections=4096, max_keepalive_connections=512)
        timeout = httpx.Timeout(300.0, connect=60.0)
        self.client = httpx.AsyncClient(limits=limits, timeout=timeout)
        self.ongoing = [0] * len(self.ports)
        self.max_queue_skew = 8

    def _get_hash_key(self, body_bytes: bytes) -> str:
        try:
            payload = json.loads(body_bytes)
            if "prompt" in payload:
                prompt_data = payload["prompt"]
                if isinstance(prompt_data, list):
                    return str(prompt_data[:64])
                return str(prompt_data)[:256]
            if "messages" in payload and payload["messages"]:
                return str(payload["messages"][0])
        except Exception:
            pass
        return ""

    def _select_worker(self, hash_key: str) -> int:
        num_workers = len(self.ports)
        if hash_key:
            hash_val = int(hashlib.md5(hash_key.encode("utf-8")).hexdigest(), 16)
            target_worker = hash_val % num_workers
            min_load = min(self.ongoing)
            # 当目标节点负载倾斜超过阈值，动态卸载到最小负载节点
            if self.ongoing[target_worker] - min_load > self.max_queue_skew:
                worker_id = self.ongoing.index(min_load)
            else:
                worker_id = target_worker
        else:
            worker_id = self.ongoing.index(min(self.ongoing))

        self.ongoing[worker_id] += 1
        return worker_id

    def _release_worker(self, worker_id: int):
        self.ongoing[worker_id] = max(0, self.ongoing[worker_id] - 1)

    async def __call__(self, request: Request):
        path = request.url.path
        if not path.startswith("/"):
            path = "/" + path
        if request.url.query:
            path = f"{path}?{request.url.query}"

        req_headers = {k: v for k, v in request.headers.items() if k.lower() != "host"}
        body = await request.body()
        hash_key = self._get_hash_key(body)

        worker_id = self._select_worker(hash_key)
        port = self.ports[worker_id]
        target_url = f"http://127.0.0.1:{port}{path}"

        req = self.client.build_request(
            method=request.method,
            url=target_url,
            headers=req_headers,
            content=body
        )

        try:
            resp = await self.client.send(req, stream=True)
        except Exception:
            self._release_worker(worker_id)
            raise

        resp_headers = dict(resp.headers)
        resp_headers["X-Ray-Replica-ID"] = f"replica_{worker_id}"
        resp_headers["X-Ray-Node-ID"] = f"node_{worker_id}"
        resp_headers["X-SGLang-Backend"] = f"backend_{worker_id}"

        async def body_stream():
            try:
                async for chunk in resp.aiter_raw():
                    yield chunk
            finally:
                await resp.aclose()
                self._release_worker(worker_id)

        return StreamingResponse(
            body_stream(),
            status_code=resp.status_code,
            headers=resp_headers,
            media_type=resp.headers.get("content-type")
        )

serve.start(http_options={"host": "0.0.0.0", "port": 8000})
router_app = HybridPrefixAwareRouter.bind()
serve.run(router_app, name="llm_router", route_prefix="/")

print("Ray Serve HybridPrefixAwareRouter (Group D) 已部署完毕，监听端口 8000")
try:
    while True:
        time.sleep(1)
except KeyboardInterrupt:
    pass